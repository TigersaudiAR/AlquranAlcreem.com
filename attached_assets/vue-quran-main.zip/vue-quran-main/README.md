# vue-quran

<img src="./src/assets/logo.png" alt="vue-quran">

```shell
$ npm install && npm run dev
```
